<xsl:stylesheet version="1.0"
      xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:variable name="x"/>

<xsl:template match="doc">
<doc x="{$x}"/>
</xsl:template>

</xsl:stylesheet>
